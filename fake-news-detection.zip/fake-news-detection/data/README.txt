Place the dataset here.

Easiest: from the project folder run
    python download_data.py
This downloads the ISOT "Fake and Real News" dataset (Fake.csv + True.csv,
~44,900 articles, the dataset cited in the thesis) — no Kaggle account needed.

Then train:
    python train.py --fake data/Fake.csv --true data/True.csv

The model included in models/ was already trained on this full dataset.
